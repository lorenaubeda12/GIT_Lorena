# Android-MVP-with-Retrofit
[ ![Example](https://img.shields.io/badge/Example-Android%20MVP%20with%20Retrofit%202.0-green.svg)](https://medium.com/@shri_chaudhari/working-with-mvp-and-retrofit-2-0-in-android-4016253ab3fc)
> This is the sample app to show how we can use MVP architecture along with Retrofit 2.0 library in our Android App.

### [Tutorial](https://medium.com/@shri_chaudhari/working-with-mvp-and-retrofit-2-0-in-android-4016253ab3fc )
### [Live Demo](https://youtu.be/SfUmjYn_B8E)
### [Download the app](https://github.com/AndroInfo/Android-MVP-with-Retrofit/releases/download/v1.0/moviedb.apk)
### Screenshots
![movie](https://user-images.githubusercontent.com/7821455/39565651-66f2bcbc-4ed6-11e8-80b6-e7e13cfb299b.png)

## License
This project is licensed under the MIT License - see the [LICENSE.md](https://github.com/AndroInfo/Android-MVP-with-Retrofit/blob/master/LICENSE) file for details
